// ─── Thresholds ────────────────────────────────────────────────────────────
const WARN_THRESHOLD   = 70;   // % → turns amber
const DANGER_THRESHOLD = 90;   // % → turns red
const POLL_MINUTES     = 1;    // how often to check (1 = every 60 seconds)

// ─── State ─────────────────────────────────────────────────────────────────
let cachedOrgId = null;

// ─── Icon drawing ──────────────────────────────────────────────────────────
function getColor(percent) {
  if (percent === null || percent === undefined) return '#6b7280'; // grey
  if (percent >= DANGER_THRESHOLD) return '#dc2626';              // red
  if (percent >= WARN_THRESHOLD)   return '#d97706';              // amber
  return '#16a34a';                                               // green
}

function drawIcon(percent) {
  const size = 128;
  const canvas = new OffscreenCanvas(size, size);
  const ctx    = canvas.getContext('2d');
  const color  = getColor(percent);
  const cx = size / 2;
  const cy = size / 2;
  const r  = size / 2;

  // ── Filled circle ──────────────────────────────────────────────
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();

  // ── Number ─────────────────────────────────────────────────────
  ctx.fillStyle    = 'white';
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';

  if (percent !== null && percent !== undefined) {
    const text = String(Math.round(percent));
    // Scale font so any number (1–100) always fits comfortably inside the circle
    const fontSize = text.length === 3 ? 52   // "100"
                   : text.length === 2 ? 68   // "72", "99"
                   :                     82;  // "4", "9"
    ctx.font = `900 ${fontSize}px Arial`;
    ctx.fillText(text, cx, cy);
  } else {
    ctx.font = '900 72px Arial';
    ctx.fillText('?', cx, cy);
  }

  return ctx.getImageData(0, 0, size, size);
}

function updateIcon(percent) {
  const imageData = drawIcon(percent);
  chrome.action.setIcon({ imageData });

  const label = percent !== null
    ? `Claudometer — 5-hr session: ${percent}%`
    : 'Claudometer — not logged in or loading…';
  chrome.action.setTitle({ title: label });
}

// ─── API helpers ────────────────────────────────────────────────────────────
async function getOrgId() {
  // Return in-memory cache first
  if (cachedOrgId) return cachedOrgId;

  // Try storage cache (survives service-worker restarts)
  const stored = await chrome.storage.local.get(['orgId', 'orgCachedAt']);
  const cacheAge = Date.now() - (stored.orgCachedAt || 0);
  if (stored.orgId && cacheAge < 24 * 60 * 60 * 1000) {
    cachedOrgId = stored.orgId;
    return cachedOrgId;
  }

  // Fresh fetch
  const resp = await fetch('https://claude.ai/api/organizations', {
    credentials: 'include'
  });
  if (!resp.ok) return null;

  const orgs = await resp.json();
  if (!Array.isArray(orgs) || orgs.length === 0) return null;

  cachedOrgId = orgs[0].uuid;
  chrome.storage.local.set({ orgId: cachedOrgId, orgCachedAt: Date.now() });
  return cachedOrgId;
}

async function fetchUsage() {
  try {
    const orgId = await getOrgId();
    if (!orgId) {
      updateIcon(null);
      chrome.storage.local.set({ status: 'not_logged_in', lastFetched: Date.now() });
      return;
    }

    const resp = await fetch(
      `https://claude.ai/api/organizations/${orgId}/usage`,
      { credentials: 'include' }
    );

    if (!resp.ok) {
      updateIcon(null);
      chrome.storage.local.set({ status: 'error', lastFetched: Date.now() });
      return;
    }

    const data = await resp.json();

    // Save full data for the popup to read
    chrome.storage.local.set({
      lastData: data,
      lastFetched: Date.now(),
      status: 'ok'
    });

    // Icon tracks the 5-hour session (most urgent limit)
    const fiveHour = data?.five_hour?.utilization ?? null;
    updateIcon(fiveHour);

  } catch (err) {
    console.error('[Claude Tracker]', err);
    updateIcon(null);
    chrome.storage.local.set({ status: 'error', lastFetched: Date.now() });
  }
}

// ─── Lifecycle ───────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  updateIcon(null); // grey "?" until first fetch
  chrome.alarms.create('poll', { periodInMinutes: POLL_MINUTES });
  fetchUsage();
});

chrome.runtime.onStartup.addListener(() => {
  updateIcon(null);
  fetchUsage();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'poll') fetchUsage();
});

// ─── Messages from popup ─────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.type === 'GET_DATA') {
    chrome.storage.local.get(['lastData', 'lastFetched', 'status'], reply);
    return true; // keep channel open for async reply
  }
  if (msg.type === 'REFRESH') {
    fetchUsage().then(() => reply({ ok: true }));
    return true;
  }
  if (msg.type === 'CLEAR_ORG') {
    cachedOrgId = null;
    chrome.storage.local.remove(['orgId', 'orgCachedAt']);
    fetchUsage().then(() => reply({ ok: true }));
    return true;
  }
});
