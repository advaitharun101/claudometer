const WARN    = 70;
const DANGER  = 90;

function colorClass(pct) {
  if (pct === null || pct === undefined) return 'grey';
  if (pct >= DANGER) return 'red';
  if (pct >= WARN)   return 'amber';
  return 'green';
}

function formatTime(isoString) {
  if (!isoString) return null;
  const d = new Date(isoString);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function renderMetric(label, pct, resetsAt) {
  const cls   = colorClass(pct);
  const width = pct !== null ? Math.min(pct, 100) : 0;
  const reset = resetsAt ? `resets ${formatTime(resetsAt)}` : '';

  return `
    <div class="metric">
      <div class="metric-header">
        <span class="metric-label">${label}</span>
        <span class="metric-value color-${cls}">
          ${pct !== null ? pct + '%' : '—'}
        </span>
      </div>
      <div class="bar-track">
        <div class="bar-fill color-${cls}" style="width:${width}%"></div>
      </div>
      ${reset ? `<span class="reset-label">${reset}</span>` : ''}
    </div>`;
}

function render(lastData, lastFetched, status) {
  const content = document.getElementById('content');
  const updated = document.getElementById('lastUpdated');

  // Timestamp
  if (lastFetched) {
    const ago = Math.round((Date.now() - lastFetched) / 1000);
    updated.textContent = ago < 5 ? 'just now' : `${ago}s ago`;
  }

  if (status === 'not_logged_in') {
    content.innerHTML = '<div class="error-msg">Not logged into claude.ai</div>';
    return;
  }
  if (!lastData || status === 'error') {
    content.innerHTML = '<div class="error-msg">Could not fetch usage data</div>';
    return;
  }

  const fh   = lastData.five_hour;
  const sd   = lastData.seven_day;
  const opus = lastData.seven_day_opus;

  let html = '';
  html += renderMetric('5-hour session', fh?.utilization   ?? null, fh?.resets_at);
  html += renderMetric('Weekly',         sd?.utilization   ?? null, sd?.resets_at);
  if (opus) {
    html += renderMetric('Weekly · Opus', opus?.utilization ?? null, opus?.resets_at);
  }

  content.innerHTML = html;
}

// ── Boot ──────────────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ type: 'GET_DATA' }, (resp) => {
  if (resp) render(resp.lastData, resp.lastFetched, resp.status);
});

// ── Refresh button ────────────────────────────────────────────────────────────
document.getElementById('refreshBtn').addEventListener('click', () => {
  document.getElementById('content').innerHTML = '<div class="loading">Refreshing…</div>';
  chrome.runtime.sendMessage({ type: 'REFRESH' }, () => {
    chrome.runtime.sendMessage({ type: 'GET_DATA' }, (resp) => {
      if (resp) render(resp.lastData, resp.lastFetched, resp.status);
    });
  });
});

// ── Clear org cache ───────────────────────────────────────────────────────────
document.getElementById('clearOrgBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CLEAR_ORG' }, () => {
    chrome.runtime.sendMessage({ type: 'GET_DATA' }, (resp) => {
      if (resp) render(resp.lastData, resp.lastFetched, resp.status);
    });
  });
});
